probe file board/kestrel-88.md
